# TechWorld – image-path-proof version

Open `index.html` with VS Code Live Server. Product images are embedded directly in `index.html` and `script.js`, so image paths will not break if the `assets` folder is uploaded incorrectly.

For GitHub, upload/replace these four files at the repository root: `index.html`, `style.css`, `script.js`, and `README.md`. No assets folder is required for images in this version.

This is a demo storefront. Product images and prices are illustrative; checkout is simulation-only and no real payment is processed.
